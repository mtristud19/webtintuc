<!DOCTYPE html>
<html>

<head>
    <title>NewsFeed</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/animate.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/font.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/li-scroller.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/slick.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/jquery.fancybox.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/theme.css">
    <link rel="stylesheet" type="text/css" href="/asset/frontend/css/style.css">
   
   
    <!--[if lt IE 9]>
<script src="assets/js/html5shiv.min.js"></script>
<script src="assets/js/respond.min.js"></script>
<![endif]-->

</head>

<body>
    <div id="preloader">
        <div id="status">&nbsp;</div>
    </div>
    <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
    <div class="container">
         <!-- Header Start -->
        <?php echo $__env->make("clients.layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Header end -->
        <!-- Navbar Start -->
        
        
        <!-- Navbar end -->
      
        <?php echo $__env->yieldContent('content'); ?>
        <!--Content Right -->
        
        <!--ContentRight End -->
    </div>
    </section>
    <!--Footer Start -->
    <?php echo $__env->make("clients.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Footer End -->
    </div>
    <!--Script Start -->
    <?php echo $__env->make("clients.layouts.script", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>;
    <!--Script End -->
</body>

</html><?php /**PATH C:\wamp64\www\webtintuc\resources\views/clients/layouts/masteru.blade.php ENDPATH**/ ?>