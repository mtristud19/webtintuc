
<?php $__env->startSection('content'); ?>
<div class="container-fluid pt-4 px-4 ">
    <div class="row g-4 d-flex justify-content-center">
        <div class="col-sm-12 col-xl-6">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Cập nhật tin tức</h6>
                <div class="container-fluid">
                    <form action="/admin/tintuc/update" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="put">
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">ID tin tức </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputPassword3" name="idtintuc" value="<?php echo e($data->idtintuc); ?>" readonly>

                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Tiêu đề</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputPassword3" name="tieude" value="<?php echo e($data->tieude); ?>">
                                <?php $__errorArgs = ['tieude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Hình ảnh</label>
                            <div class="col-sm-10">
                                <input type="file" class="form-control" id="inputPassword3" name="img">
                                <img src="<?php echo e(asset('storage/public_img/'.$data->img)); ?>" style="width: 100px;">

                                <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Mô tả</label>
                            <div class="col-sm-10">
                                <textarea cols="30" rows="10" class="form-control" id="inputPassword3" name="mota"><?php echo e($data->mota); ?></textarea>

                                <?php $__errorArgs = ['mota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Nội dung</label>
                            <div class="col-sm-10">
                                <textarea cols="30" rows="10" class="form-control" id="inputPassword3" name="noidung"><?php echo e($data->noidung); ?></textarea>

                                <?php $__errorArgs = ['noidung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Ngày đăng</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" id="inputPassword3" name="ngaydang" value="<?php echo e($data->ngaydang); ?>">
                                <?php $__errorArgs = ['ngaydang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Nhóm tin</label>
                            <div class="col-sm-10">
                                <select class="form-control" id="Nhomtin" name="idnhomtin">
                                    <?php $__currentLoopData = $theloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->loaitin->nhomtin->idnhomtin==$item->idnhomtin): ?>
                                        <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                        value="<?php echo e($item->idnhomtin); ?>"><?php echo e($item->tennhomtin); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Loại tin</label>
                            <div class="col-sm-10">
                                <select class="form-control" id="Loaitin" name="idloaitin">

                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">Lượt xem</label>
                            <div class="col-sm-10">
                                <input type="number" min="0" step="1" class="form-control" id="inputPassword3" name="luotxem" value="<?php echo e($data->luotxem); ?>">
                                <?php $__errorArgs = ['luotxem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="inputPassword3" class="col-sm-2 col-form-label">HOT</label>
                            <div class="col-sm-10">
                                <input type="radio" value="1" name="hot" <?php if($data->hot==1): ?>
                                <?php echo e("checked"); ?>

                                <?php endif; ?>
                                > Có
                                <input type="radio" value="0" name="hot" <?php if($data->hot==0): ?>
                                <?php echo e("checked"); ?>

                                <?php endif; ?>
                                > Không
                                <?php $__errorArgs = ['hot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="alert alert-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end mt-3">
                            <input type="submit" class="btn btn-success me-2" value="Sửa">
                            <a href="/admin/tintuc" class="btn btn-danger me-2">Trở về</a>
                        </div>
                    </form>
                </div>

            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Quản lý Comment</h6>

                    <?php if(session()->has('mess')): ?>
                    <p class="alert alert-primary sm-4">
                        <?php echo e(session('mess')); ?>

                    </p>
                    <?php endif; ?>
                    <table class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">User</th>
                                <th scope="col">Nội dung</th>
                                <th scope="col">Ngày đăng</th>
                                <th></th>

                            </tr>
                        </thead>
                        <?php $__currentLoopData = $data->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <td><?php echo e($cm->idbinhluan); ?></td>

                                <td><?php echo e($cm->user->ten); ?></td>
                                <td><?php echo e($cm->noidung); ?></td>
                                <td><?php echo e($cm->ngaydang); ?></td>
                                <th>
                                    <form action="/admin/comment/destroy/<?php echo e($cm->idbinhluan); ?>/<?php echo e($data->idtintuc); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="delete">
                                        <input type="submit" value="xóa" class="btn btn-danger">
                                    </form>
                                </th>
                             
                                </td>
                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </table>

                </div>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        var idNhomTin = $('#Nhomtin').val();
        $.get("/admin/ajax/loaitin/" + idNhomTin, function(data) {
            $("#Loaitin").html(data);
        });
        $("#Nhomtin").change(function() {
            var idNhomTin = $(this).val();
            $.get("/admin/ajax/loaitin/" + idNhomTin, function(data) {
                $("#Loaitin").html(data);
            });
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/masterad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/admin/tintuc/edittt.blade.php ENDPATH**/ ?>