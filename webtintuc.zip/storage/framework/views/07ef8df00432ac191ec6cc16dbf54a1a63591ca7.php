
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('clients.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.html">Home</a></li>
              <li><a href="#"><?php echo e($tintuc->loaitin->nhomtin->tennhomtin); ?></a></li>
              <li class="active"><?php echo e($tintuc->loaitin->tenloaitin); ?></li>
            </ol>
            <h1><?php echo e($tintuc->tieude); ?></h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>VanDepTrai</a> <span><i class="fa fa-calendar"></i><?php echo e($tintuc->ngaydang); ?></span> <a href="/loaitin/<?php echo e($tintuc->idloaitin); ?>"><i class="fa fa-tags"></i><?php echo e($tintuc->loaitin->tenloaitin); ?></a> </div>
            <div class="single_page_content"> <img class="img-center" src="<?php echo e(asset('storage/public_img/'.$tintuc->img)); ?>" alt="">
              <p><?php echo e($tintuc->mota); ?></p>
              <blockquote> <?php echo e($tintuc->noidung); ?> </blockquote>
          
              
           
            </div>
            <div class="social_link">
              <ul class="sociallink_nav">
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
              </ul>
            </div>
            <div class="related_post">
              <h2>Related Post <i class="fa fa-thumbs-o-up"></i></h2>
              <ul class="spost_nav wow fadeInDown animated">
                <li>
                  <div class="media"> <a class="media-left" href="single_page.html"> <img src="../images/post_img1.jpg" alt=""> </a>
                    <div class="media-body"> <a class="catg_title" href="single_page.html"> Aliquam malesuada diam eget turpis varius</a> </div>
                  </div>
                </li>
                <li>
                  <div class="media"> <a class="media-left" href="single_page.html"> <img src="../images/post_img2.jpg" alt=""> </a>
                    <div class="media-body"> <a class="catg_title" href="single_page.html"> Aliquam malesuada diam eget turpis varius</a> </div>
                  </div>
                </li>
                <li>
                  <div class="media"> <a class="media-left" href="single_page.html"> <img src="../images/post_img1.jpg" alt=""> </a>
                    <div class="media-body"> <a class="catg_title" href="single_page.html"> Aliquam malesuada diam eget turpis varius</a> </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
        <div>
        </div>
        <div>
        </div>
        </a> </nav>
        <?php echo $__env->make("clients.layouts.contentRight", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('clients/layouts/masteru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/clients/pages/tintuc.blade.php ENDPATH**/ ?>