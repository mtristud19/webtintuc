
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('clients.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-4 col-sm-4" >
        <div class="left_content">
          <div class="contact_area">
            
          <h2><?php echo e($loaitin->tenloaitin); ?></h2>
           <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div >
              <ul class="business_catgnav  wow fadeInDown" style="align-content: center;">
                <li>
                  <figure class="bsbig_fig"> <a href="pages/single_page.html" class="featured_img"> <img alt="" src="<?php echo e(asset('storage/public_img/'.$tt->img)); ?>" height="300px" > <span class="overlay"></span> </a>
                    <figcaption> <a href="pages/single_page.html"><?php echo e($tt->tieude); ?></a> </figcaption>
                    <p><?php echo e($tt->mota); ?></p>
                    <a class="btn btn-info" href="/tintuc/<?php echo e($tt->idtintuc); ?>">Xem them <span class="glyphicon glyphicon-chevron-right"></span></a>
                  </figure>
                </li>
              </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           
          </div>
          <div style="text-align:right;"> <?php echo e($tintuc->links()); ?></div>
        </div>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <div class="single_sidebar">
            <h2><span>Last Post</span></h2>
            <ul class="spost_nav">
              <li>
                <div class="media wow fadeInDown"> <a href="single_page.html" class="media-left"> <img alt="" src="../images/post_img1.jpg"> </a>
                  <div class="media-body"> <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 1</a> </div>
                </div>
              </li>
              <li>
                <div class="media wow fadeInDown"> <a href="single_page.html" class="media-left"> <img alt="" src="../images/post_img2.jpg"> </a>
                  <div class="media-body"> <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 2</a> </div>
                </div>
              </li>
              <li>
                <div class="media wow fadeInDown"> <a href="single_page.html" class="media-left"> <img alt="" src="../images/post_img1.jpg"> </a>
                  <div class="media-body"> <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 3</a> </div>
                </div>
              </li>
              <li>
                <div class="media wow fadeInDown"> <a href="single_page.html" class="media-left"> <img alt="" src="../images/post_img2.jpg"> </a>
                  <div class="media-body"> <a href="single_page.html" class="catg_title"> Aliquam malesuada diam eget turpis varius 4</a> </div>
                </div>
              </li>
            </ul>
          </div>
        </aside>
      </div>
      
      
    </div>

  

  </section>
      
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('clients/layouts/masteru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/clients/pages/loaitin.blade.php ENDPATH**/ ?>