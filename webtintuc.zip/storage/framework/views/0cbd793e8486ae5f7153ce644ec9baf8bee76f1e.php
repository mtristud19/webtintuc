
<?php $__env->startSection('content'); ?>
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-md-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Quản lý người dùng</h6>
                
                <?php if(session()->has('mess')): ?>
                <p class="alert alert-primary sm-4">
                    <?php echo e(session('mess')); ?>

                </p>
                <?php endif; ?>
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th scope="col">ID người dùng</th>
                            <th scope="col">Tên người dùng</th>
                            <th scope="col">Email</th>
                            <th></th>

                        </tr>
                    </thead>
                    <?php $__currentLoopData = $nguoidung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td><?php echo e($item->idusers); ?></td>
                            <td><?php echo e($item->ten); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <th>
                                <form action="/admin/users/destroy/<?php echo e($item->idusers); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="delete">
                                    <input type="submit" value="xóa" class="btn btn-danger">
                                </form>
                            </th>
     
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>

    </div>
</div>
<!-- Table End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/masterad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/admin/users/index.blade.php ENDPATH**/ ?>