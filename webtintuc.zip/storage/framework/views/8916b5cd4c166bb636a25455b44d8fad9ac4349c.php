<header id="header">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="header_top">
                <div class="header_top_left">
                    <ul class="top_nav">
                        <?php if(session()->has('users')): ?>
                        <form action="/find" method="GET">
                        <li><a href="/users/info/<?php echo e(session()->get('users')['idusers']); ?>" >Info</a></li>
                        <li>
                            <p style="color: pink;">Hello <?php echo e(session()->get('users')['ten']); ?></p>
                        </li>
                        <li><a href="/logoutuser">Log Out</a></li>
                        
                        <li><input class="input" placeholder="Tìm kiếm ở đây" name="keyword"></li>
                        <li><input type="submit" class="search-btn" value="Tìm kiếm"></input></li>
                        </form>
                        <?php else: ?>
                        <form action="/find" method="GET">
                        <li><a href="/loginuser">Sign In</a></li>
                        <li><a href="/registeruser">Register</a></li>
                     
                        <li><input class="input" placeholder="Tìm kiếm ở đây" name="keyword"></li>
                        <li><input type="submit" class="search-btn" value="Tìm kiếm"></input></li>
                        </form>
                        <?php endif; ?>
                    </ul>



                </div>

            </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12">
            <div class="header_bottom">
                <div class="logo_area"><img src="/storage/public_img/stu.jpg" width="286px" height="100px"></div>
                <div class="add_banner"><img src="/storage/public_img/banner.jpg" width="728px" height="70px" alt=""></div>
            </div>
        </div>
    </div>
</header><?php /**PATH C:\wamp64\www\webtintuc\resources\views/clients/layouts/header.blade.php ENDPATH**/ ?>