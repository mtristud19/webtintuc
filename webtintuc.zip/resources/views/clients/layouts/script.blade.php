<script src="/asset/frontend/js/jquery.min.js"></script>
    <script src="/asset/frontend/js/wow.min.js"></script>
    <script src="/asset/frontend/js/bootstrap.min.js"></script>
    <script src="/asset/frontend/js/slick.min.js"></script>
    <script src="/asset/frontend/js/jquery.li-scroller.1.0.js"></script>
    <script src="/asset/frontend/js/jquery.newsTicker.min.js"></script>
    <script src="/asset/frontend/js/jquery.fancybox.pack.js"></script>
    <script src="/asset/frontend/js/custom.js"></script>